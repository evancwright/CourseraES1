Author: Evan C. Wright
Repository for Intro to Embedded Systems, Assignment 1
6/11/2019

To build this project, type: gcc -o stats.out stats.c
To run this project, type: ./stats.out

alternately...you could just run 'make'


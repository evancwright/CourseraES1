/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief This is the implementation file for assignment 1 (array stats)
 * 
 * This file declares an array of unsigned chars then invokes functions
 * to print, sort, and perform calculations on the array, then display
 * the results of the calculations on the console.
 *
 * @author Evan C. Wright
 * @date 6/11/2019
 *
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  /* Other Variable Declarations Go Here */
  /* Statistics and Printing Functions Go Here */
  printf("Evan C. Wright, assignment 1:\n\n");
  printf("The unsorted data is:\n");
  print_array(test,SIZE);
  
  printf("The sorted data is:\n");
  sort_array(test,SIZE);
  print_array(test,SIZE);
  
  printf("Array stats are:\n");
  print_statistics(test,SIZE);
}

/* Add other Implementation File Code Here */
/*print_array() - Given an array of data and a length, prints the array to the screen*/
void print_array(unsigned char *data, unsigned int len)
{
	int i=0;
	for (i=0; i < len; i++)
	{
		printf("%d\t",(int)data[i]);
		if ((i+1)%5==0)
			printf("\n");
	}
	printf("\n");
}

/*- Given an array of data and a length, returns the maximum*/
unsigned char find_maximum(unsigned char *data, unsigned int len)
{
	int i=0;
	unsigned char max=0;
 	for (i=0; i < len; i++)
	{
		if (data[i] > max)
		{
			max = data[i];
		}
	}
	return max;
}
 
/*find_minimum() - Given an array of data and a length, returns the minimum*/
unsigned char find_minimum(unsigned char *data, unsigned int len)
{
	unsigned char min=0xFF;
	int i=0;
	
	for (i=0; i < len; i++)
	{
		if (data[i] < min)
		{
			min = data[i];
		}
	}
	return min;
}

/*find_median() - Given an array of data and a length, returns the median value*/
unsigned char find_median(unsigned char *data, unsigned int len)
{
	unsigned char min = find_minimum(data,len);
	unsigned char max = find_maximum(data,len);
	return ((max-min)/2);
}


/*print_statistics() - A function that prints the statistics of an array including minimum, maximum, mean, and median.*/
void print_statistics(unsigned char *data, unsigned int len)
{
	unsigned char min = find_minimum(data, len);
	unsigned char max = find_maximum(data, len);
	unsigned char mean = find_mean(data, len);
	unsigned char median = find_median(data, len);
	
	printf("Min=%d\tMax=%d\tMean=%d\tMedian=%d\n",min,max,mean,median);
}



/*find_mean() - Given an array of data and a length, returns the mean */
unsigned char find_mean(unsigned char *data, unsigned int len)
{
	int sum =0;
	int i=0;
	for (i=0; i < len; i++)
	{
		sum += data[i];
	}
	return sum/len;
}

/*- Given an array of data and a length, sorts the array from largest to smallest. (The zeroth Element should be the largest value, and the last element (n-1) should be the smallest value. )*/

void sort_array(unsigned char *data, unsigned int len) 
{
	int i=0,j=0;
	int top=0;
	unsigned char temp=0;
	
	for (int i=0; i < len; i++)
	{
		for (j=0; j < top; j++)
		{
			if (data[j] < data[top])
			{
				temp = data[j];
				data[j]=data[top];
				data[top]=temp;
			}
		}
		top++;
	}
}

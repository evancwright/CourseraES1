/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h 
 * @brief Function declarations for stats.c 
 *
 * This file declares functions uses to perform analysis
 * on an array on unsigned characters
 *
 * @author Evan C. Wright
 * @date 6/11/2019 
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

/**
 * @brief print_statistics
 *
 * Prints the min,max,median,and mean of the supplied array
 *
 * @param unsigned char * -  an array of unsigned characters
 * @param unsigned int - the length of the array
 *
 * @return none
 */
void print_statistics(unsigned char *data, unsigned int len);

/**
 * @brief print_array
 *
 * Prints the contents of the array to the console
 *
 * @param unsigned char * -  an array of unsigned characters
 * @param unsigned int - the length of the array
 *
 * @return none
 */
void print_array(unsigned char *data, unsigned int len);

/**
 * @brief find_median
 *
 * Returns the median value in the supplied array
 *
 * @param unsigned char * - an array of unsigned characters
 * @param unsigned int - the length of the array
 *
 * @return unsigned char (the median value)
 */
unsigned char find_median(unsigned char *data, unsigned int len);

/**
 * @brief find_mean
 *
 * Returns the median value in the supplied array
 *
 * @param unsigned char * - an array of unsigned characters
 * @param unsigned int - the length of the array
 *
 * @return unsigned char (the mean value)
 */
unsigned char find_mean(unsigned char *data, unsigned int len);

/**
 * @brief find_maximum
 *
 * Returns the largest value in the supplied array
 *
 * @param unsigned char * - an array of unsigned characters
 * @param unsigned int - the length of the array
 *
 * @return unsigned char (the max value)
 */
unsigned char find_maximum(unsigned char *data, unsigned int len);

/**
 * @brief find_minimum
 *
 * Returns the smallest value in the supplied array
 *
 * @param unsigned char * - an array of unsigned characters
 * @param unsigned int - the length of the array
 *
 * @return unsigned char (the min value)
 */
unsigned char find_minimum(unsigned char *data, unsigned int len);

/**
 * @brief sort_array
 *
 * Sorts the input array in descending order in place.
 *
 * @param unsigned char * - an array of unsigned characters
 * @param unsigned int - the length of the array
 *
 * @return none
 */
void sort_array(unsigned char *data, unsigned int len);

#endif /* __STATS_H__ */
